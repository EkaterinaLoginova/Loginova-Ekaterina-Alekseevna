﻿Public Class Form3
    Private Sub Назад_Click(sender As Object, e As EventArgs) Handles Назад.Click
        Me.Visible = False
        Form1.Show()
    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

    End Sub
End Class